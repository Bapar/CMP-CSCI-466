click on index.html to run this code.

