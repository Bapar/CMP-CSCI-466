----Folders----
Demo1 Folder:
	Contains the files from demo1.

Reports Folder:
	Contains projects 1, 2, and 3.


----Files----
ProductBrochure.pdf: 
	*An overview of our programs features (current and planned).
	*System Requirements.
	*A screen shot of the website.

TechnicalDocumentation.pdf:
	*How to start playing the game
	*Current features
	*System Requirments
	*How to troubleshoot the game.
	*Licence

Contributions.pdf:
	List of what each developer contributed to demo 1.

UserDocumentation.pdf:
	This is a tutorial to show the user how to take advantage of all the features in the game.

--------
How to run this program:
	Simply double click SourceCode/index.html. 
	Be sure to use Chrome, or Firefox web browsers.

